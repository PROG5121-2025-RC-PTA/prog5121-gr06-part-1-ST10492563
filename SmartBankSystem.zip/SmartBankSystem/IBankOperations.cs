﻿namespace SmartBankSystem
{
    public interface IBankOperations
    {
        void Deposit(double amount);
        void Withdraw(double amount);
        void Transfer(BankAccount receiver, double amount);
        double CheckBalance();
        void ViewTransactionHistory();
    }
}