﻿using System.Collections.Generic;

namespace SmartBankSystem
{
    public static class BankData
    {
        public static List<BankAccount> Accounts { get; }
            = new List<BankAccount>
        {
            new BankAccount(
                "ACC1001",
                "John Mokoena",
                "1234",
                5000),

            new BankAccount(
                "ACC1002",
                "Thabo Dlamini",
                "2345",
                7500),

            new BankAccount(
                "ACC1003",
                "Lerato Nkosi",
                "3456",
                12000),

            new BankAccount(
                "ACC1004",
                "Sipho Khumalo",
                "4567",
                3500),

            new BankAccount(
                "ACC1005",
                "Ayanda Ndlovu",
                "5678",
                9000)
        };
    }
}
