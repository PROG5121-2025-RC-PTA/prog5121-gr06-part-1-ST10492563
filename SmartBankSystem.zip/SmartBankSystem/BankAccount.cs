﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace SmartBankSystem
{
    public class BankAccount : IBankOperations
    {
        private string accountNumber;
        private string customerName;
        private string pin;
        private double balance;
        private List<string> transactions;

        public string AccountNumber
        {
            get { return accountNumber; }
        }

        public string CustomerName
        {
            get { return customerName; }
        }

        public string Pin
        {
            get { return pin; }
        }

        public double Balance
        {
            get { return balance; }
        }

        public List<string> Transactions
        {
            get { return transactions; }
        }

        public BankAccount(
            string accountNumber,
            string customerName,
            string pin,
            double balance)
        {
            this.accountNumber = accountNumber;
            this.customerName = customerName;
            this.pin = pin;
            this.balance = balance;

            transactions = new List<string>();
        }

        public void Deposit(double amount)
        {
            if (amount <= 0)
                throw new ArgumentException(
                    "Deposit amount must be greater than zero.");

            balance += amount;

            transactions.Add(
                DateTime.Now.ToString("dd/MM/yyyy HH:mm")
                + " Deposit: R"
                + amount.ToString("N2"));
        }

        public void Withdraw(double amount)
        {
            if (amount <= 0)
                throw new ArgumentException(
                    "Withdrawal amount must be greater than zero.");

            if (amount > balance)
                throw new InvalidOperationException(
                    "Insufficient funds.");

            balance -= amount;

            transactions.Add(
                DateTime.Now.ToString("dd/MM/yyyy HH:mm")
                + " Withdraw: R"
                + amount.ToString("N2"));
        }

        public void Transfer(BankAccount receiver, double amount)
        {
            if (receiver == null)
                throw new ArgumentException(
                    "Recipient account does not exist.");

            if (receiver == this)
                throw new InvalidOperationException(
                    "You cannot transfer money to your own account.");

            if (amount <= 0)
                throw new ArgumentException(
                    "Transfer amount must be greater than zero.");

            if (amount > balance)
                throw new InvalidOperationException(
                    "Insufficient funds.");

            balance -= amount;
            receiver.balance += amount;

            transactions.Add(
                DateTime.Now.ToString("dd/MM/yyyy HH:mm")
                + " Transfer to "
                + receiver.AccountNumber
                + ": R"
                + amount.ToString("N2"));

            receiver.transactions.Add(
                DateTime.Now.ToString("dd/MM/yyyy HH:mm")
                + " Received from "
                + AccountNumber
                + ": R"
                + amount.ToString("N2"));
        }

        public double CheckBalance()
        {
            return balance;
        }

        public void ViewTransactionHistory()
        {
            if (transactions.Count == 0)
            {
                MessageBox.Show(
                    "No transactions found.",
                    "Transaction History",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                return;
            }

            MessageBox.Show(
                string.Join(Environment.NewLine, transactions),
                "Transaction History",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }
    }
}