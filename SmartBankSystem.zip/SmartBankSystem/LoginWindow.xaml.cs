﻿using System;
using System.Linq;
using System.Windows;

namespace SmartBankSystem
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string accountNumber =
                    txtAccountNumber.Text.Trim();

                string pin =
                    txtPin.Password.Trim();

                if (string.IsNullOrWhiteSpace(accountNumber) ||
                    string.IsNullOrWhiteSpace(pin))
                {
                    MessageBox.Show(
                        "Please enter your Account Number and PIN.",
                        "Login Error",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);

                    return;
                }

                if (!accountNumber.StartsWith("ACC") ||
                    accountNumber.Length != 7)
                {
                    MessageBox.Show(
                        "Invalid Account Number.",
                        "Login Error",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);

                    return;
                }

                if (!pin.All(char.IsDigit) ||
                    pin.Length != 4)
                {
                    MessageBox.Show(
                        "PIN must contain exactly 4 numbers.",
                        "Login Error",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);

                    return;
                }

                BankAccount account =
                    BankData.Accounts.FirstOrDefault(
                        a => a.AccountNumber.Equals(
                            accountNumber,
                            StringComparison.OrdinalIgnoreCase));

                if (account == null)
                {
                    MessageBox.Show(
                        "Account does not exist.",
                        "Login Failed",
                        MessageBoxButton.OK,
                        MessageBoxImage.Error);

                    return;
                }

                if (account.Pin != pin)
                {
                    MessageBox.Show(
                        "Incorrect PIN.",
                        "Login Failed",
                        MessageBoxButton.OK,
                        MessageBoxImage.Error);

                    return;
                }

                MessageBox.Show(
                    "Welcome, " + account.CustomerName + "!",
                    "Login Successful",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                BankingDashboard dashboard =
                    new BankingDashboard(account, this);

                dashboard.Show();

                Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "An unexpected error occurred: "
                    + ex.Message,
                    "Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }
    }
}