﻿using System;
using System.Linq;
using System.Windows;

namespace SmartBankSystem
{
    public partial class BankingDashboard : Window
    {
        private BankAccount currentAccount;
        private LoginWindow loginWindow;

        public BankingDashboard(
            BankAccount account,
            LoginWindow loginWindow)
        {
            InitializeComponent();

            currentAccount = account;
            this.loginWindow = loginWindow;

            DisplayCustomerDetails();
            RefreshTransactions();
        }

        private void DisplayCustomerDetails()
        {
            lblCustomerName.Text =
                currentAccount.CustomerName;

            lblAccountNumber.Text =
                currentAccount.AccountNumber;

            lblBalance.Text =
                "R" + currentAccount.Balance.ToString("N2");
        }

        private bool GetAmount(out double amount)
        {
            if (!double.TryParse(
                txtAmount.Text,
                out amount))
            {
                MessageBox.Show(
                    "Please enter a valid amount.",
                    "Input Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return false;
            }

            if (amount <= 0)
            {
                MessageBox.Show(
                    "Amount must be greater than zero.",
                    "Input Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return false;
            }

            return true;
        }

        private void Deposit_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                if (!GetAmount(out double amount))
                    return;

                currentAccount.Deposit(amount);

                DisplayCustomerDetails();
                RefreshTransactions();

                txtAmount.Clear();

                MessageBox.Show(
                    "Deposit successful.",
                    "Success",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Deposit Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void Withdraw_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                if (!GetAmount(out double amount))
                    return;

                currentAccount.Withdraw(amount);

                DisplayCustomerDetails();
                RefreshTransactions();

                txtAmount.Clear();

                MessageBox.Show(
                    "Withdrawal successful.",
                    "Success",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Withdrawal Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void Balance_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                MessageBox.Show(
                    "Your current balance is R"
                    + currentAccount.CheckBalance().ToString("N2"),
                    "Current Balance",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void Transfer_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                string receiverNumber =
                    txtReceiver.Text.Trim();

                if (string.IsNullOrWhiteSpace(receiverNumber))
                {
                    MessageBox.Show(
                        "Please enter the recipient Account Number.",
                        "Input Error",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);

                    return;
                }

                if (!GetAmount(out double amount))
                    return;

                BankAccount receiver =
                    BankData.Accounts.FirstOrDefault(
                        a => a.AccountNumber.Equals(
                            receiverNumber,
                            StringComparison.OrdinalIgnoreCase));

                if (receiver == null)
                {
                    MessageBox.Show(
                        "Recipient account does not exist.",
                        "Transfer Error",
                        MessageBoxButton.OK,
                        MessageBoxImage.Error);

                    return;
                }

                currentAccount.Transfer(
                    receiver,
                    amount);

                DisplayCustomerDetails();
                RefreshTransactions();

                txtAmount.Clear();
                txtReceiver.Clear();

                MessageBox.Show(
                    "Transfer successful.",
                    "Success",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Transfer Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void History_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                currentAccount.ViewTransactionHistory();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "History Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void RefreshTransactions()
        {
            lstTransactions.Items.Clear();

            if (currentAccount.Transactions.Count == 0)
            {
                lstTransactions.Items.Add(
                    "No transactions yet.");

                return;
            }

            foreach (string transaction
                     in currentAccount.Transactions)
            {
                lstTransactions.Items.Add(transaction);
            }
        }

        private void Logout_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                loginWindow.Show();
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Logout Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        protected override void OnClosed(
            EventArgs e)
        {
            if (loginWindow != null &&
                !loginWindow.IsVisible)
            {
                loginWindow.Show();
            }

            base.OnClosed(e);
        }
    }
}